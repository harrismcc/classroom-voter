from . import test_polltypes

def main():
    """
    Run all tests!
    """
    print("To run all tests, use `python3 -m unittest discover tests` in the home directory!")
    return 0

main()